<?php
/**
 * @author Semenov Alexander <semenov@skeeks.com>
 * @link http://skeeks.com/
 * @copyright 2010 SkeekS (СкикС)
 * @date 28.02.2017
 */
return [
    'bootstrap' => [],
    'components' => [],
    'params' => [],
];
