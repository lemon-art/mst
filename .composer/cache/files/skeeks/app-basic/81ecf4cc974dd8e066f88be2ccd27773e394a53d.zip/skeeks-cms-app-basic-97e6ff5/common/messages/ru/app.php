<?php
/**
 * app
 *
 * @author Semenov Alexander <semenov@skeeks.com>
 * @link http://skeeks.com/
 * @copyright 2010-2014 SkeekS (Sx)
 * @date 17.10.2014
 * @since 1.0.0
 */
return array_merge(
    (array) include_once \Yii::getAlias("@skeeks/cms/messages/ru/main.php"),
    //(array) include_once \Yii::getAlias("@skeeks/modules/cms/game/messages/ru/main.php"),
    [
        "Common translates"         =>  "Общие сообщения"
    ]
);
