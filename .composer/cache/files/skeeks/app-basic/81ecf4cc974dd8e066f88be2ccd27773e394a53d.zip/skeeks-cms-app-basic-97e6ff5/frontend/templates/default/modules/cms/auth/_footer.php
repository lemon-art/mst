        </div>
    </div>
</section>

<? \skeeks\cms\modules\admin\widgets\Pjax::end(); ?>