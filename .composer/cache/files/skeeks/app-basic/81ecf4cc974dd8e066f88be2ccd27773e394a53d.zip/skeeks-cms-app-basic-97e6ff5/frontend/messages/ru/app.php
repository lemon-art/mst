<?php
/**
 * app
 *
 * @author Semenov Alexander <semenov@skeeks.com>
 * @link http://skeeks.com/
 * @copyright 2010-2014 SkeekS (Sx)
 * @date 17.10.2014
 * @since 1.0.0
 */

$commonMessages = include_once \Yii::getAlias("@common/messages/ru/app.php");

return array_merge($commonMessages, [
    "List of games"         =>  "Список игр"
]);
